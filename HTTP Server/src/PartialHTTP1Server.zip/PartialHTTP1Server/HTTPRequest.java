
import java.util.StringTokenizer;

public class HTTPRequest {
	private final String IF_MODIFIED = "If-Modified-Since";
	
	//request line
	private String command;
	private String uri;
	private String protocol;
	
	//header fields
	private String ifModifiedDate;
	
	//parses string to build HTTPRequest object (fields)
	public HTTPRequest(String request) {
		StringTokenizer lines = new StringTokenizer(request, "\n");
		String requestLine = lines.nextToken();
		String[] requestParams = requestLine.split(" "); //I don't believe URIs can have spaces, but if they can, this won't work
		switch(requestParams.length) {
		case 0: //missing all parameters
			command = null;
			uri = null;
			protocol = null;
			break;
		case 1: //missing 2 parameters
			command = requestParams[0];
			uri = null;
			protocol = null;
			break;
		case 2: //missing a parameter
			command = requestParams[0];
			uri = requestParams[1];
			protocol = null;
			break;
		case 3: //message is properly formatted
			command = requestParams[0];
			uri = requestParams[1];
			protocol = requestParams[2];	
			break;
		default:
			command = requestParams[0];
			uri = requestParams[1];
			protocol = requestParams[2];
			if(requestParams[3].contains(IF_MODIFIED)) {
				ifModifiedDate = requestParams[4];
				for(int i = 5; i < requestParams.length; i++) {
					ifModifiedDate = ifModifiedDate + " " + requestParams[i];
				}
			}
			break;
		}

	}
	
	public HTTPRequest(String command, String uri, String protocol) {
		this.command = command;
		this.uri = uri;
		this.protocol = protocol;
	}
	
	public String toString() {
		String request = "";
		String headerField = "";
		String requestLine = command + " " + uri + " " + protocol;
		if (ifModifiedDate != "") {
			headerField = IF_MODIFIED +": " + ifModifiedDate;
		}
		request += requestLine + "\n" + headerField + "\r\n";
		return request;
	}
	
	public String getCommand() {
		return command;
	}
	
	public String getUri() {
		return uri;
	}
	
	public String getProtocol() {
		return protocol;
	}
	
	public String getProtocolVersionNumber() {
		String[] protocolWithVersion = protocol.split("/");
		if(protocolWithVersion.length == 2) {
			return protocolWithVersion[1];
		}
		else return null;
	}
	public String getIfModifiedBy() {
		return ifModifiedDate;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
